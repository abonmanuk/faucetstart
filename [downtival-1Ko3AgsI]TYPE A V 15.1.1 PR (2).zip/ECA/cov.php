<?php
#[!] Note : (ikuti contoh data 1 - 10) dan hapus tanda '//' di depan //$ untuk mengaktifkannya
#[!] Note : Jika ingin menambahkan data ikuti format data 1 - 10
# Data #1
$w1 = "https://24.sharelink.club/claim.php?coin=BCN";
$t1 = "BCNToken=xxxx";
$p1 = "PHPSESSID=xxxx";
# Data #2
$w2 = "https://wavescoin.xyz/claim.php?coin=WAVES";
$t2 = "WAVESToken=xxxx";
$p2 = "PHPSESSID=xxxx";
# Data #3
$w3 = "https://toptap.website/ecdoge/claim.php?coin=DOGE";
$t3 = "DOGEToken=xxxx";
$p3 = "PHPSESSID=xxxx";
# Data #4
$w4 = "https://24.sharelink.club/claim.php?coin=EXG";
$t4 = "EXGToken=xxxx";
$p4 = "PHPSESSID=xxxx";
# Data #5
$w5 = "https://fastcoins.tk/claim.php?coin=DOGE";
$t5 = "DOGEToken=xxxx";
$p5 = "PHPSESSID=xxxx";
# Data #6
$w6 = "https://toptap.website/ecpot/claim.php?coin=POT";
$t6 = "POTToken=xxxx";
$p6 = "PHPSESSID=xxxx";
# Data #7
$w7 = "https://autofaucets.org/ltc24/claim.php?coin=LTC";
$t7 = "LTCToken=xxxx";
$p7 = "PHPSESSID=xxxx";
# Data #8
$w8 = "https://autofaucets.org/bcn24/claim.php?coin=BCN";
$t8 = "BCNToken=xxxx";
$p8 = "PHPSESSID=xxxx";
# Data #9
$w9 = "https://autofaucets.org/doge24/claim.php?coin=DOGE";
$t9 = "DOGEToken=xxxx";
$p9 = "PHPSESSID=xxxx";
# Data #10
$w10 = "https://www.coinrotation.com/autofaucet/claim.php?coin=ZEC";
$t10 = "ZECToken=xxxx";
$p10 = "PHPSESSID=xxxx";
?>